return math.mininteger or -9223372036854775808
