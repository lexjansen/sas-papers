local cj = require 'cjson'
return cj.encode
