local dk = require 'dkjson'
return dk.encode
