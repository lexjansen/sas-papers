local lj = require 'lunajson'
return lj.encode
