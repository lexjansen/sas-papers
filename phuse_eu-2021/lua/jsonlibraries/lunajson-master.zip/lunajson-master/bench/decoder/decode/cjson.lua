local cj = require 'cjson'
return cj.decode
