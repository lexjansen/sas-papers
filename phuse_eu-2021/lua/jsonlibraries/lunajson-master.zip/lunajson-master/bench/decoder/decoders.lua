return {
	'lunajson',
	'lunajson_sax',
	'dkjson_pure',  -- dkjson_pure must be placed former to prevent enabling lpeg support
	'dkjson_lpeg',
	'cjson',
}
